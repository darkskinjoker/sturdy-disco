package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
	// a program that asks user for a sentence and prints the first word of the sentence.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Write a message: ");
        String sentence = scanner.nextLine();

        int firstWordLocation = sentence.indexOf(" ");
        String wordOne = sentence.substring(0,firstWordLocation);

        System.out.println( "First word is " + wordOne);

    }
}
