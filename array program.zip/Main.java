package com.company;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class Main {

    public static void main(String[] args) throws Exception {

        File myFile = new File("HOMETASKREAD13LINES.txt");

        BufferedReader br
                = new BufferedReader(new FileReader(myFile));

        String str;

        while ((str = br.readLine()) != null)
            System.out.println(str);
        }
    }
