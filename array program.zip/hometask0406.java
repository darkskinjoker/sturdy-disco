package com.company;

public class Main {

    public static void main(String[] args) {
	// write your code here
        String sentence = "Great thoughts speak only to the thoughtful mind,great speech speak only to the inquisitive mind, but great actions speak to all mankind";
        String replaceWord = "great";
        String exactWordReplaced = sentence.replaceFirst(replaceWord, "wonderful");//replaces first occurrence of "great" to "wonderful"

        String replaceString=sentence.replaceAll("\\bgreat\\b","wonderful");//replaces all occurrences of "great" to "wonderful"
        //System.out.println(replaceString);
        System.out.println(exactWordReplaced);
    }
}
