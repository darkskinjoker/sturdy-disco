package com.company;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // Write a program that takes input from the user and displays that input back in upper and lower cases
        {
            System.out.println("Input--->");
            Scanner scanner = new Scanner(System.in);

            String input = scanner.nextLine();
            StringBuffer newInput = new StringBuffer(input);


            for (int i = 0; i < input.length(); i++) {

                //Checks for lower case character
                if (Character.isLowerCase(input.charAt(i))) {
                    //Convert it into upper case using toUpperCase() function
                    newInput.setCharAt(i, Character.toUpperCase(input.charAt(i)));
                }
                //Checks for upper case character
                else if (Character.isUpperCase(input.charAt(i))) {
                    //Convert it into upper case using toLowerCase() function
                    newInput.setCharAt(i, Character.toLowerCase(input.charAt(i)));
                }
            }
            System.out.println("String after case conversion : " + newInput);
        }
    }
}
