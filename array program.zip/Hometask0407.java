package com.company;

import java.util.Random;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        // a lottery program that prompts the user to guess a randomly generated number between 0 and 100000.
        //The user pays $1.00 for each guess, $2.00 for each hint, and wins $1,000,000 if the guess is correct.
        //The user enters a "q" to quit. If the user does not win, the program will show how much money the user lost.
        //If the user wins, the user will not lose the money - the winner takes it all - $1,000,000.
        Scanner scan = new Scanner(System.in);
        Scanner input = new Scanner(System.in);
        Random random = new Random();
        long from = 1;
        long to = 100000;
        int randomNumber = (int) (random.nextInt((int) (to = -1), (int) (from +100000)) + from);;
        int guessedNumber = 0;
        int attempt = 1;
        int amount = 1;
        int hint = 2;


        System.out.println(randomNumber);

        System.out.printf("The number is between 1 and 100000.", from, to);
        System.out.println("Insert $" + amount + " to continue");

        do {
            System.out.print("Enter a guess number between 1 to 100000. You have 5 attempts;\n");
            if(scan.hasNextInt()) {
                String quit = "q";
                String y = "y", n = "n";
                guessedNumber = scan.nextInt();
                if (guessedNumber == randomNumber)
                {
                    System.out.println("Your Number is Correct. YOU WIN. Total attempts = " + attempt);
                    break;
                }
                else if (guessedNumber < randomNumber){
                    System.out.println("this is attempt number " + attempt + " ,do you want a hint? y/n");
                    y = scan.nextLine();
                    if (scan.nextLine() == "y")
                    System.out.println("Your Guess Number is Smaller");
                    else
                    System.out.println("");
                }
                 else if (guessedNumber > randomNumber){
                    System.out.println("this is attempt number " + attempt + " ,do you want a hint? y/n");
                    y = scan.nextLine();
                    if (scan.nextLine() == "y")
                    System.out.println("Your Guess Number is Greater");
                    else
                    System.out.println("");
                }
                if(attempt == 5) {
                    System.out.println("You have exceeded the maximum attempt. Try Again");
                    break;
                }
                attempt++;
            }else {
                System.out.println("Enter a Valid Integer Number");
                break;
            }
        } while (guessedNumber != randomNumber);

    }
}