package com.company;

import java.util.Scanner;
// Write a method that takes an array of words and prints the longest word and the length of the longest one.
public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Please input here");

        String words = scanner.nextLine();
        String wordArray[] = words.split(" ");
        String longWord = "", shortWord = "";
        int longestWord = 0;
        int shortestWord = Integer.MAX_VALUE;
        int lengthOfWord = 0;
        for (int j = 0; j < wordArray.length; j++) {
            String word = wordArray[j];
            lengthOfWord = word.length();
            if (lengthOfWord > longestWord) {
                longWord = word;
                longestWord = lengthOfWord;
            }
        }
        System.out.println("The longest word is " + longWord);
        System.out.println("The length of the longest word is " + longestWord);
    }
}


