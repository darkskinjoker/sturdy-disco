package com.company;

public class Rectangle {
    private double length;
    private double width;


    public Rectangle () {
        length= 1.0;
        width = 5.0;
    }


    public Rectangle(double r, double w) {
        this.length = r;
        this.width = w;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getWidth() {
        return width;
    }

    public double getPerimeter() {
        return (length + width) *2;
    }
    public double getArea() {
        return length*width;
    }

    @Override
    public String toString() {
        return "Rectangle{" +
                "length=" + length +
                ", width=" + width +
                '}';
    }
}
